/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=15x15 fish fish.png 
 * Time-stamp: Tuesday 04/05/2022, 02:06:24
 * 
 * Image Information
 * -----------------
 * fish.png 15@15
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FISH_H
#define FISH_H

extern const unsigned short fish[225];
#define FISH_SIZE 450
#define FISH_LENGTH 225
#define FISH_WIDTH 15
#define FISH_HEIGHT 15

#endif

