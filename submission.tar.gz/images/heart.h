/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=15x15 heart heart.png 
 * Time-stamp: Tuesday 04/05/2022, 02:07:03
 * 
 * Image Information
 * -----------------
 * heart.png 15@15
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef HEART_H
#define HEART_H

extern const unsigned short heart[225];
#define HEART_SIZE 450
#define HEART_LENGTH 225
#define HEART_WIDTH 15
#define HEART_HEIGHT 15

#endif

