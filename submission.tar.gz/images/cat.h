/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=30x30 cat cat.png 
 * Time-stamp: Tuesday 04/05/2022, 18:41:40
 * 
 * Image Information
 * -----------------
 * cat.png 30@30
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef CAT_H
#define CAT_H

extern const unsigned short cat[900];
#define CAT_SIZE 1800
#define CAT_LENGTH 900
#define CAT_WIDTH 30
#define CAT_HEIGHT 30

#endif

