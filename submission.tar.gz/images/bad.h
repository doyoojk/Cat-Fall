/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 bad bad.png 
 * Time-stamp: Tuesday 04/05/2022, 02:08:11
 * 
 * Image Information
 * -----------------
 * bad.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BAD_H
#define BAD_H

extern const unsigned short bad[38400];
#define BAD_SIZE 76800
#define BAD_LENGTH 38400
#define BAD_WIDTH 240
#define BAD_HEIGHT 160

#endif

