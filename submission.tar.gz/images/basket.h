/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=25x25 basket basket.png 
 * Time-stamp: Tuesday 04/05/2022, 02:05:52
 * 
 * Image Information
 * -----------------
 * basket.png 25@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BASKET_H
#define BASKET_H

extern const unsigned short basket[625];
#define BASKET_SIZE 1250
#define BASKET_LENGTH 625
#define BASKET_WIDTH 25
#define BASKET_HEIGHT 25

#endif

